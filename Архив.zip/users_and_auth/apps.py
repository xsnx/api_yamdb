from django.apps import AppConfig


class UsersAndAuthConfig(AppConfig):
    name = 'users_and_auth'
